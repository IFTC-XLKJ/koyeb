function showAlert() {
    alert('感谢您的关注！');
}

contactForm.addEventListener("submit", e => {
    e.preventDefault();
    alert('感谢您的留言！');
    contactForm.reset();
});