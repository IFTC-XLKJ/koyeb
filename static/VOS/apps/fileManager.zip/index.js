const tabs = [];
onload = e => {
    API.postMessage({ type: "load" })
};